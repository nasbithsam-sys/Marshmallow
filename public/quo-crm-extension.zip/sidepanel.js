const EDITABLE_FIELDS = [
  "customerName",
  "customerNumber",
  "customerAddress",
  "numberName",
  "service",
  "direction",
  "scheduleRequirement"
];

// Lead capture UI elements
const form = document.getElementById("lead-form");
const feedback = document.getElementById("feedback");
const clearButton = document.getElementById("clear-form");
const createLeadButton = document.getElementById("create-lead");
const autoPickNumberBtn = document.getElementById("auto-pick-number");
const autoPickNumberNameBtn = document.getElementById("auto-pick-number-name");

// Auth UI elements
const loginContainer = document.getElementById("login-container");
const leadCaptureContainer = document.getElementById("lead-capture-container");
const loginForm = document.getElementById("login-form");
const loginEmail = document.getElementById("login-email");
const loginPassword = document.getElementById("login-password");
const accessCodeField = document.getElementById("access-code-field");
const loginAccessCode = document.getElementById("login-access-code");
const mfaField = document.getElementById("mfa-field");
const loginMfa = document.getElementById("login-mfa");
const loginBtn = document.getElementById("login-btn");
const userSessionBar = document.getElementById("user-session-bar");
const userSessionEmail = document.getElementById("user-session-email");
const logoutBtn = document.getElementById("logout-btn");

// Reports UI elements
const reportTodayCount = document.getElementById("report-today-count");
const reportYesterdayCount = document.getElementById("report-yesterday-count");
const reportHistoryList = document.getElementById("report-history-list");

let currentDraft = null;
let pendingMfaFactorId = null;
let mfaRequired = false;
let accessCodeRequired = false;

initialize();

async function initialize() {
  // Bind Auth events
  loginForm.addEventListener("submit", handleLoginSubmit);
  logoutBtn.addEventListener("click", handleLogout);

  // Check initial authentication
  const authResponse = await chrome.runtime.sendMessage({ type: "CHECK_AUTH" });
  if (authResponse && authResponse.success) {
    showLeadCaptureUI(authResponse);
  } else {
    showLoginUI();
  }

  // Listen to both input and change events to support immediate radio button syncing
  form.addEventListener("input", handleFormInput);
  form.addEventListener("change", handleFormInput);
  form.addEventListener("submit", handleCreateLead);
  clearButton.addEventListener("click", handleClearForm);
  autoPickNumberBtn.addEventListener("click", handleAutoPickNumber);
  autoPickNumberNameBtn.addEventListener("click", handleAutoPickNumberName);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "DRAFT_UPDATED" && message.draft) {
      currentDraft = message.draft;
      renderDraft(currentDraft);
      showFeedback("Draft updated from selected text.", "info");
    }
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.leadDraft?.newValue) {
      return;
    }

    currentDraft = changes.leadDraft.newValue;
    renderDraft(currentDraft);
  });
}

function showLoginUI() {
  loginContainer.hidden = false;
  leadCaptureContainer.hidden = true;
  userSessionBar.hidden = true;
  clearFeedback();
}

function showLeadCaptureUI(authResponse) {
  loginContainer.hidden = true;
  leadCaptureContainer.hidden = false;
  userSessionBar.hidden = false;
  
  const displayEmail = authResponse.fullName || authResponse.user?.email || "Authenticated";
  userSessionEmail.textContent = displayEmail;
  userSessionEmail.title = authResponse.user?.email || "";

  clearFeedback();
  loadDraft();
  loadReports();
}

async function loadDraft() {
  const response = await chrome.runtime.sendMessage({ type: "GET_DRAFT" });
  currentDraft = response.draft;
  renderDraft(currentDraft);
}

// Authentication Logic
async function handleLoginSubmit(event) {
  event.preventDefault();
  clearFeedback();
  loginBtn.disabled = true;
  const originalText = loginBtn.innerHTML;
  loginBtn.innerHTML = `<span>Verifying...</span>`;

  try {
    const email = loginEmail.value.trim();
    const password = loginPassword.value;

    // 1. MFA Submission case
    if (mfaRequired && pendingMfaFactorId) {
      const code = loginMfa.value.trim();
      if (!code || code.length !== 6) {
        throw new Error("MFA Code must be exactly 6 digits.");
      }
      const response = await chrome.runtime.sendMessage({
        type: "VERIFY_MFA",
        factorId: pendingMfaFactorId,
        code
      });
      if (response && response.success) {
        mfaRequired = false;
        pendingMfaFactorId = null;
        mfaField.hidden = true;
        loginMfa.required = false;
        showLeadCaptureUI(response);
      } else {
        throw new Error(response.error || "MFA Verification failed.");
      }
      return;
    }

    // 2. Access Code Submission case
    if (accessCodeRequired) {
      const code = loginAccessCode.value.trim();
      if (!code || code.length !== 6) {
        throw new Error("Access Code must be exactly 6 digits.");
      }
      const response = await chrome.runtime.sendMessage({
        type: "VERIFY_ACCESS_CODE",
        code
      });
      if (response && response.success) {
        accessCodeRequired = false;
        accessCodeField.hidden = true;
        loginAccessCode.required = false;
        showLeadCaptureUI(response);
      } else {
        throw new Error(response.error || "Access code verification failed.");
      }
      return;
    }

    // 3. Initial Login
    const response = await chrome.runtime.sendMessage({
      type: "LOGIN",
      email,
      password
    });

    if (!response || !response.success) {
      throw new Error(response?.error || "Login failed. Check your credentials.");
    }

    if (response.mfaRequired) {
      mfaRequired = true;
      pendingMfaFactorId = response.factorId;
      mfaField.hidden = false;
      loginMfa.required = true;
      showFeedback("MFA required. Enter your authenticator code below.", "info");
    } else if (response.accessCodeRequired) {
      accessCodeRequired = true;
      accessCodeField.hidden = false;
      loginAccessCode.required = true;
      showFeedback("Access code required. Enter the 6-digit code from your administrator below.", "info");
    } else {
      showLeadCaptureUI(response);
    }
  } catch (error) {
    showFeedback(error.message || "Authentication failed.", "error");
  } finally {
    loginBtn.disabled = false;
    loginBtn.innerHTML = originalText;
  }
}

async function handleLogout() {
  clearFeedback();
  try {
    await chrome.runtime.sendMessage({ type: "LOGOUT" });
    mfaRequired = false;
    pendingMfaFactorId = null;
    accessCodeRequired = false;
    mfaField.hidden = true;
    accessCodeField.hidden = true;
    loginMfa.required = false;
    loginAccessCode.required = false;
    loginPassword.value = "";
    showLoginUI();
  } catch (error) {
    showFeedback("Logout failed: " + error.message, "error");
  }
}

// Reports Logic
async function loadReports() {
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_EXTENSION_REPORT" });
    if (response && response.success) {
      reportTodayCount.textContent = response.todayCount;
      reportYesterdayCount.textContent = response.yesterdayCount;
      renderHistoryList(response.history);
    }
  } catch (error) {
    console.error("Could not load extension reports", error);
  }
}

function renderHistoryList(history) {
  reportHistoryList.innerHTML = "";
  if (!history || history.length === 0) {
    reportHistoryList.innerHTML = `<li class="history-empty">No recent extension leads.</li>`;
    return;
  }

  history.forEach((lead) => {
    const li = document.createElement("li");
    li.className = "history-item";

    const dateStr = formatCapturedAt(lead.createdAt);
    
    // Status dot color mapping
    let dotColor = "var(--text-muted)";
    if (lead.status === "urgent_job" || lead.status === "need_tech") {
      dotColor = "#ef4444"; // red
    } else if (lead.status === "scheduled") {
      dotColor = "var(--primary-teal)"; // teal
    } else if (lead.status === "job_done" || lead.status === "paid") {
      dotColor = "#10b981"; // green
    } else if (lead.status === "cancelled") {
      dotColor = "#6b7280"; // grey
    }

    li.innerHTML = `
      <div class="history-item__left">
        <span class="history-item__title">${escapeHtml(lead.customerName || "No Name")}</span>
        <span class="history-item__phone">${escapeHtml(lead.customerPhone || "No Number")}</span>
        <span class="history-item__date">${escapeHtml(dateStr)}</span>
      </div>
      <div class="history-item__right">
        <span class="history-item__job-id">${escapeHtml(lead.jobId)}</span>
        <span class="history-item__status-dot" style="background-color: ${dotColor};" title="${escapeHtml(lead.status)}"></span>
      </div>
    `;
    reportHistoryList.appendChild(li);
  });
}

// Lead Form logic
async function handleFormInput(event) {
  const target = event.target;
  if (!target.name || !EDITABLE_FIELDS.includes(target.name)) {
    return;
  }

  const updatedDraft = {
    ...currentDraft,
    [target.name]: target.value
  };

  currentDraft = updatedDraft;
  await chrome.runtime.sendMessage({
    type: "UPDATE_DRAFT",
    payload: {
      [target.name]: target.value
    }
  });
}

async function handleClearForm() {
  const response = await chrome.runtime.sendMessage({ type: "CLEAR_DRAFT" });
  currentDraft = response.draft;
  renderDraft(currentDraft);
  showFeedback("Draft cleared.", "info");
}

async function handleCreateLead(event) {
  event.preventDefault();
  clearFeedback();
  createLeadButton.disabled = true;
  createLeadButton.innerHTML = `<svg class="spinner" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" style="animation: spin 0.8s linear infinite"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0 1 10 10" stroke="currentColor" stroke-linecap="round"/></svg><span>Creating...</span>`;

  try {
    const response = await chrome.runtime.sendMessage({ type: "CREATE_LEAD" });

    if (!response?.success) {
      throw new Error(response?.error || "Lead creation failed.");
    }

    // Auto-clear the draft on successful creation
    const clearResponse = await chrome.runtime.sendMessage({ type: "CLEAR_DRAFT" });
    currentDraft = clearResponse.draft;
    renderDraft(currentDraft);

    const leadUrl = response.response?.leadUrl;
    const successHtml = leadUrl
      ? `Lead created successfully. <a href="${escapeHtml(leadUrl)}" target="_blank" rel="noreferrer">Open Lead</a>`
      : "Lead created successfully.";

    showFeedback(successHtml, "success", true);
    
    // Refresh stats and history list!
    loadReports();
  } catch (error) {
    showFeedback(error.message || "Lead creation failed.", "error");
  } finally {
    createLeadButton.disabled = false;
    createLeadButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg><span>Create Lead</span>`;
  }
}

function renderDraft(draft) {
  // Update editable fields safely to prevent cursor jumping
  const inputs = [
    "customerName",
    "customerNumber",
    "customerAddress",
    "numberName",
    "service",
    "scheduleRequirement"
  ];

  inputs.forEach((field) => {
    const element = form[field];
    if (element) {
      const val = draft[field] || "";
      if (element.value !== val) {
        element.value = val;
      }
    }
  });

  // Sync direction (radio buttons / segmented control)
  const directionVal = draft.direction || "incoming";
  const radios = form.elements["direction"];
  if (radios) {
    radios.value = directionVal;
  }

  // Safely select and update read-only fields outside the main form element
  const capturedAtInput = document.querySelector('[name="capturedAt"]');
  const sourceUrlInput = document.querySelector('[name="sourceUrl"]');

  if (capturedAtInput) {
    const rawTime = draft.capturedAt || "";
    const formattedTime = rawTime ? formatCapturedAt(rawTime) : "";
    if (capturedAtInput.value !== formattedTime) {
      capturedAtInput.value = formattedTime;
    }
  }

  if (sourceUrlInput) {
    const rawUrl = draft.sourceUrl || "";
    if (sourceUrlInput.value !== rawUrl) {
      sourceUrlInput.value = rawUrl;
    }
  }
}

function formatCapturedAt(isoString) {
  try {
    const date = new Date(isoString);
    return date.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (e) {
    return isoString;
  }
}

function showFeedback(message, type, allowHtml = false) {
  feedback.hidden = false;
  feedback.className = `feedback feedback--${type}`;
  
  let iconSvg = "";
  if (type === "success") {
    iconSvg = `<svg class="feedback__icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else if (type === "error") {
    iconSvg = `<svg class="feedback__icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  } else {
    iconSvg = `<svg class="feedback__icon" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
  }
  
  const contentSpan = document.createElement("span");
  contentSpan.className = "feedback__content";
  if (allowHtml) {
    contentSpan.innerHTML = message;
  } else {
    contentSpan.textContent = message;
  }
  
  feedback.innerHTML = "";
  feedback.appendChild(createSvgElement(iconSvg));
  feedback.appendChild(contentSpan);
  
  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.className = "feedback__close";
  closeBtn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
  closeBtn.addEventListener("click", clearFeedback);
  feedback.appendChild(closeBtn);
}

function createSvgElement(svgString) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgString, "image/svg+xml");
  return doc.documentElement;
}

function clearFeedback() {
  feedback.hidden = true;
  feedback.textContent = "";
  feedback.className = "feedback";
}

function escapeHtml(value) {
  if (!value) return "";
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

async function handleAutoPickNumber() {
  clearFeedback();
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      throw new Error("No active browser tab found.");
    }

    const response = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_CUSTOMER_NUMBER" });
    
    if (response && response.success && response.number) {
      form.customerNumber.value = response.number;

      await chrome.runtime.sendMessage({
        type: "UPDATE_DRAFT",
        payload: {
          customerNumber: response.number
        }
      });

      currentDraft.customerNumber = response.number;
      showFeedback(`Customer number auto-picked: ${response.number}`, "success");
    } else {
      throw new Error("Could not find any customer number in the header of this page.");
    }
  } catch (error) {
    let errMsg = error.message || "Failed to auto-pick number.";
    if (errMsg.includes("Receiving end does not exist") || errMsg.includes("Could not establish connection")) {
      errMsg = "Could not connect to quo.com page. Please ensure you are active on the quo.com chat page and refresh the page.";
    }
    showFeedback(errMsg, "error");
  }
}

async function handleAutoPickNumberName() {
  clearFeedback();
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      throw new Error("No active browser tab found.");
    }

    const response = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE_NUMBER_NAME" });
    
    if (response && response.success && response.name) {
      form.numberName.value = response.name;

      await chrome.runtime.sendMessage({
        type: "UPDATE_DRAFT",
        payload: {
          numberName: response.name
        }
      });

      currentDraft.numberName = response.name;
      showFeedback(`Number name auto-picked: ${response.name}`, "success");
    } else {
      throw new Error("Could not find active channel/number name on this page.");
    }
  } catch (error) {
    let errMsg = error.message || "Failed to auto-pick number name.";
    if (errMsg.includes("Receiving end does not exist") || errMsg.includes("Could not establish connection")) {
      errMsg = "Could not connect to quo.com page. Please ensure you are active on the quo.com chat page and refresh the page.";
    }
    showFeedback(errMsg, "error");
  }
}
