const FIELD_ACTIONS = [
  {
    label: "Customer Name",
    field: "customerName",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`
  },
  {
    label: "Customer Number",
    field: "customerNumber",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`
  },
  {
    label: "Address",
    field: "customerAddress",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>`
  },
  {
    label: "Number Name",
    field: "numberName",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>`
  },
  {
    label: "Service",
    field: "service",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`
  },
  {
    label: "Schedule Req.",
    field: "scheduleRequirement",
    icon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`
  }
];

const MENU_ID = "quo-crm-floating-menu";
let menuElement = null;
let hideMenuTimeout = null;
let latestSelectionText = "";
let latestSelectionRect = null;
let suppressMenuUntilSelectionChanges = false;

initialize();

function initialize() {
  notifyPageReady();
  document.addEventListener("selectionchange", cacheSelectionState);
  document.addEventListener("mouseup", handleSelectionEvent);
  document.addEventListener("keyup", handleSelectionEvent);
  document.addEventListener("mousedown", handleDocumentMouseDown, true);
  window.addEventListener("scroll", hideMenu, true);
  window.addEventListener("blur", hideMenu);
}

function handleSelectionEvent() {
  cacheSelectionState();
  window.clearTimeout(hideMenuTimeout);
  hideMenuTimeout = window.setTimeout(showMenuForSelection, 10);
}

function handleDocumentMouseDown(event) {
  if (menuElement && menuElement.contains(event.target)) {
    return;
  }

  hideMenu();
}

function showMenuForSelection() {
  if (suppressMenuUntilSelectionChanges || !latestSelectionText || !latestSelectionRect) {
    hideMenu();
    return;
  }

  if (!menuElement) {
    menuElement = buildMenu();
    document.body.appendChild(menuElement);
  }

  positionMenu(latestSelectionRect);
  menuElement.dataset.selectedText = latestSelectionText;
  menuElement.classList.remove("quo-hidden");
}

function buildMenu() {
  const container = document.createElement("div");
  container.id = MENU_ID;
  container.classList.add("quo-hidden");
  container.addEventListener("mousedown", handleMenuMouseDown);
  container.addEventListener("click", handleMenuClick);

  const header = document.createElement("div");
  header.className = "quo-menu-header";

  const title = document.createElement("div");
  title.className = "quo-title";
  title.textContent = "Assign Field";

  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.className = "quo-close-btn";
  closeButton.dataset.action = "close";
  closeButton.setAttribute("aria-label", "Close assignment menu");
  closeButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;

  header.append(title, closeButton);
  container.appendChild(header);

  const actionGrid = document.createElement("div");
  actionGrid.className = "quo-action-grid";

  FIELD_ACTIONS.forEach(({ label, field, icon }) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "quo-field-btn";
    button.dataset.field = field;
    button.innerHTML = `${icon}<span>${label}</span>`;
    actionGrid.appendChild(button);
  });

  container.appendChild(actionGrid);
  return container;
}

function positionMenu(rect) {
  const margin = 12;
  const estimatedHeight = 240; // Estimated height for vertical dropdown layout
  let top = rect.top - estimatedHeight;

  if (top < margin) {
    top = rect.bottom + margin;
  }

  const left = Math.min(
    window.innerWidth - 210,
    Math.max(margin, rect.left + rect.width / 2 - 95)
  );

  menuElement.style.top = `${top}px`;
  menuElement.style.left = `${left}px`;
}

async function assignSelection(field) {
  const selectedText = menuElement?.dataset.selectedText || latestSelectionText || "";

  if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
    alert("The extension was reloaded or updated. Please refresh the page to continue capturing leads.");
    hideMenu();
    return;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: "ASSIGN_SELECTION_TO_FIELD",
      field,
      selectedText
    });

    if (!response?.success) {
      throw new Error(response?.error || "Failed to capture selected text.");
    }

    suppressMenuUntilSelectionChanges = true;
    clearActiveSelection();
    hideMenu();
  } catch (error) {
    console.error("Quo CRM Lead Capture:", error);
    alert(error.message || "Failed to assign selected text.");
  }
}

function handleDismissMenu(event) {
  event.preventDefault();
  event.stopPropagation();
  suppressMenuUntilSelectionChanges = true;
  clearActiveSelection();
  hideMenu();
}

function handleMenuMouseDown(event) {
  if (!event.target.closest("button")) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();
}

async function handleMenuClick(event) {
  const button = event.target.closest("button");
  if (!button) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();

  if (button.dataset.action === "close") {
    handleDismissMenu(event);
    return;
  }

  if (button.dataset.field) {
    await assignSelection(button.dataset.field);
  }
}

function hideMenu() {
  if (menuElement) {
    menuElement.classList.add("quo-hidden");
  }
}

function cacheSelectionState() {
  const inputSelection = getInputSelection();
  if (inputSelection) {
    suppressMenuUntilSelectionChanges = false;
    latestSelectionText = inputSelection.text;
    latestSelectionRect = inputSelection.rect;
    return;
  }

  const selection = window.getSelection();
  const selectedText = selection ? selection.toString().trim() : "";

  if (!selection || !selectedText || selection.rangeCount === 0) {
    latestSelectionText = "";
    latestSelectionRect = null;
    suppressMenuUntilSelectionChanges = false;
    return;
  }

  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();

  if (!rect || (!rect.width && !rect.height)) {
    latestSelectionText = "";
    latestSelectionRect = null;
    return;
  }

  latestSelectionText = selectedText;
  latestSelectionRect = rect;
  suppressMenuUntilSelectionChanges = false;
}

function getInputSelection() {
  const activeElement = document.activeElement;
  if (!activeElement) {
    return null;
  }

  const isTextInput =
    activeElement instanceof HTMLTextAreaElement ||
    (activeElement instanceof HTMLInputElement &&
      ["text", "search", "tel", "url", "email"].includes(activeElement.type));

  if (!isTextInput) {
    return null;
  }

  const start = activeElement.selectionStart;
  const end = activeElement.selectionEnd;
  if (typeof start !== "number" || typeof end !== "number" || start === end) {
    return null;
  }

  const text = activeElement.value.slice(start, end).trim();
  if (!text) {
    return null;
  }

  const rect = activeElement.getBoundingClientRect();
  return {
    text,
    rect
  };
}

function clearActiveSelection() {
  const activeElement = document.activeElement;
  if (
    activeElement &&
    (activeElement instanceof HTMLTextAreaElement ||
      activeElement instanceof HTMLInputElement)
  ) {
    const end = activeElement.selectionEnd;
    if (typeof end === "number") {
      activeElement.setSelectionRange(end, end);
    }
  }

  const selection = window.getSelection();
  if (selection) {
    selection.removeAllRanges();
  }

  latestSelectionText = "";
  latestSelectionRect = null;
}

async function notifyPageReady() {
  try {
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      await chrome.runtime.sendMessage({
        type: "PAGE_CONTEXT_READY",
        url: window.location.href
      });
    }
  } catch (error) {
    console.warn("Quo CRM Lead Capture: could not initialize page context.", error);
  }
}

// Listen for messages from the sidepanel
if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "SCRAPE_CUSTOMER_NUMBER") {
      const number = scrapeCustomerNumber();
      sendResponse({ success: !!number, number });
    } else if (message?.type === "SCRAPE_NUMBER_NAME") {
      const name = scrapeNumberName();
      sendResponse({ success: !!name, name });
    } else if (message?.type === "SCRAPE_CHAT_IMAGES") {
      const images = scrapeChatImages();
      sendResponse({ success: !!images, images });
    }
    return true; // Keep message channel open for async response
  });
}

function scrapeNumberName() {
  const activeLink = document.querySelector('[aria-current="page"], [aria-current="true"]');
  if (!activeLink) {
    return null;
  }

  // Scan all children nodes to find the name text
  const elements = activeLink.querySelectorAll('span, div');
  let potentialNames = [];

  for (const el of elements) {
    if (el.children.length === 0) {
      const text = el.textContent.trim();
      if (!text) continue;

      // Skip line phone numbers
      if (isPhoneNumber(text)) {
        continue;
      }

      // Skip emoji flag/icons (usually length <= 2)
      if (text.length <= 2) {
        continue;
      }

      potentialNames.push(text);
    }
  }

  // The name is usually the longest text
  if (potentialNames.length > 0) {
    potentialNames.sort((a, b) => b.length - a.length);
    return potentialNames[0];
  }

  return null;
}

function scrapeCustomerNumber() {
  // Scope search to the active chat header container
  let header = null;

  const quickActions = document.getElementById("message-quick-actions");
  if (quickActions) {
    header = quickActions.closest('div._160c0eh1') || quickActions.parentElement;
  }

  if (!header) {
    header = document.querySelector('div._160c0eh1.xw761z0.xw761z1') || 
             document.querySelector('div._10cjd4h0');
  }

  if (header) {
    // Strategy 1: Look for avatar label inside the header
    const avatarEl = header.querySelector('[aria-label*="\'s avatar"]');
    if (avatarEl) {
      const label = avatarEl.getAttribute('aria-label');
      const match = label.match(/^([+\d\s()\-]+)'s avatar/);
      if (match) {
        const potential = match[1].trim();
        if (isPhoneNumber(potential)) {
          return potential;
        }
      }
    }

    // Strategy 2: Scan elements inside the header for phone number pattern
    const phoneRegex = /^\+?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
    const allDivs = header.querySelectorAll('div, button, span');
    for (const el of allDivs) {
      if (el.children.length === 0 || (el.children.length === 1 && el.firstElementChild.tagName.toUpperCase() === 'SVG')) {
        const text = el.textContent.trim();
        if (phoneRegex.test(text)) {
          return text;
        }
      }
    }

    // Strategy 3: Broader search inside copy buttons inside header
    const copyButtons = header.querySelectorAll('button');
    for (const btn of copyButtons) {
      // Check the button's own text content first (handles direct text child nodes alongside SVG copy icons)
      const btnText = btn.textContent.trim();
      if (phoneRegex.test(btnText) || isPhoneNumber(btnText)) {
        return btnText;
      }
      const divs = btn.querySelectorAll('div');
      for (const div of divs) {
        const text = div.textContent.trim();
        if (phoneRegex.test(text)) {
          return text;
        }
      }
    }

    // Strategy 4: Fallback - broad scan of all potential text-containing elements inside the header
    const candidates = header.querySelectorAll('button, span, div, p, a');
    for (const candidate of candidates) {
      const text = candidate.textContent.trim();
      if (isPhoneNumber(text)) {
        return text;
      }
    }
  }

  return null;
}

function isPhoneNumber(str) {
  const cleaned = str.replace(/[()+\-\s]/g, '');
  return /^\d{7,15}$/.test(cleaned);
}

function scrapeChatImages() {
  const images = Array.from(document.querySelectorAll('img'));
  const chatImages = [];
  
  images.forEach(img => {
    // 1. Get raw image source from src or lazy-load attributes
    let imageUrl = img.src || "";
    const dataSrc = img.getAttribute('data-src') || 
                    img.getAttribute('data-original') || 
                    img.getAttribute('data-original-src') ||
                    img.getAttribute('data-url') ||
                    img.getAttribute('data-lazy') ||
                    img.getAttribute('srcset');
                    
    if (dataSrc) {
      const cleanSrc = dataSrc.trim().split(/[\s,]+/)[0];
      if (cleanSrc) imageUrl = cleanSrc;
    }
    
    if (!imageUrl) return;
    
    // Resolve relative URLs to absolute
    try {
      imageUrl = new URL(imageUrl, window.location.origin).href;
    } catch (e) {
      return;
    }

    // If the image is inside an <a> tag pointing to an image, check the href
    const parentLink = img.closest('a');
    if (parentLink && parentLink.href) {
      const href = parentLink.href.toLowerCase();
      if (
        href.endsWith('.jpg') || 
        href.endsWith('.jpeg') || 
        href.endsWith('.png') || 
        href.endsWith('.webp') || 
        href.endsWith('.gif') ||
        href.includes('/attachments/') ||
        href.includes('/media/') ||
        href.includes('/uploads/')
      ) {
        imageUrl = parentLink.href;
      }
    }

    // 2. Filter out explicit avatars/profile photos
    const classStr = (img.className || "").toLowerCase();
    const altStr = (img.alt || "").toLowerCase();
    const ariaLabel = (img.getAttribute('aria-label') || "").toLowerCase();
    const parentClass = img.parentElement ? (img.parentElement.className || "").toLowerCase() : "";
    
    if (
      classStr.includes('avatar') || 
      altStr.includes('avatar') || 
      ariaLabel.includes('avatar') ||
      parentClass.includes('avatar') ||
      classStr.includes('profile') ||
      altStr.includes('profile') ||
      parentClass.includes('profile')
    ) {
      return;
    }

    // 3. Filter out small icons/logos if they have explicitly measured small sizes
    const rect = img.getBoundingClientRect();
    const width = rect.width || img.clientWidth || img.naturalWidth || 0;
    const height = rect.height || img.clientHeight || img.naturalHeight || 0;
    
    // Skip if it's explicitly measured as very small (e.g. <= 32px)
    if ((width > 0 && width <= 32) || (height > 0 && height <= 32)) {
      return;
    }
    
    // Skip typical tracking pixels / spacer images (1x1)
    if (width === 1 && height === 1) {
      return;
    }

    // Skip SVG data URLs
    if (imageUrl.startsWith('data:image/svg+xml')) {
      return;
    }
    
    // Avoid duplicates
    if (!chatImages.includes(imageUrl)) {
      chatImages.push(imageUrl);
    }
  });
  
  return chatImages;
}
